package com.gdtsk.recorder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Bolha flutuante pequena e translúcida. Fica na tela o tempo todo enquanto o app está ativo.
 *
 *  - Em espera:  [GDT]  ● gravar   ⟲15 (últimos 15 s)   ✕ (fechar a bolha)
 *  - Gravando:   ● 00:12  ⏸ pausar  ■ parar  ⟲15
 *
 * Arraste segurando por qualquer parte fora dos botões (rótulo "GDT" ou cronômetro).
 *
 * Atenção: o Android não oferece como excluir uma janela de sobreposição da captura de tela.
 * Em muitos aparelhos a bolha aparece no vídeo; por isso ela é opcional e a notificação
 * (que não fica sobre a tela) tem os mesmos controles.
 */
class FloatingBubble(
    private val ctx: Context,
    private val elapsedMs: () -> Long,
    private val replayEnabled: Boolean,
    private val onRecord: () -> Unit,
    private val onTogglePause: () -> Unit,
    private val onStopRec: () -> Unit,
    private val onReplay: () -> Unit,
    private val onClose: () -> Unit,
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var timer: TextView? = null
    private var dotShape: GradientDrawable? = null

    private var recording = false
    private var paused = false

    private val tick = object : Runnable {
        override fun run() {
            if (root == null) return
            if (recording) timer?.text = format(elapsedMs())
            handler.postDelayed(this, 500)
        }
    }

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 240
    }

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    fun show() {
        if (root != null) return
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(2), dp(3), dp(2))
            background = GradientDrawable().apply {
                setColor(0x70000000) // preto ~44% opaco
                cornerRadius = dp(16).toFloat()
            }
        }

        // Arrastar: toque fora dos botões (no rótulo/cronômetro ou nas bordas).
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(bar, params) }
                }
            }
            true
        }

        try {
            wm.addView(bar, params)
            root = bar
            render()
            handler.postDelayed(tick, 500)
        } catch (e: Exception) {
            root = null // sem permissão de sobreposição: segue só com a notificação
        }
    }

    /** Alterna entre "em espera" e "gravando" (e pausado). */
    fun setState(recording: Boolean, paused: Boolean) {
        this.recording = recording
        this.paused = paused
        render()
    }

    private fun render() {
        val bar = root ?: return
        bar.removeAllViews()
        timer = null
        dotShape = null

        fun btn(kind: Int, tint: Int, click: () -> Unit) = IconButton(ctx, kind, tint).apply {
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(30))
            setOnClickListener { click() }
        }

        if (!recording) {
            bar.addView(TextView(ctx).apply {
                text = "GDT"
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xB3FFFFFF.toInt())
                includeFontPadding = false
                setPadding(0, 0, dp(4), 0)
            })
            bar.addView(btn(IconButton.REC, RED) { onRecord() })
            if (replayEnabled) bar.addView(btn(IconButton.REPLAY, WHITE) { onReplay() })
            bar.addView(btn(IconButton.CLOSE, 0xB3FFFFFF.toInt()) { onClose() })
        } else {
            val dot = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (paused) GRAY else RED)
            }
            dotShape = dot
            bar.addView(View(ctx).apply {
                background = dot
                layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).apply { marginEnd = dp(5) }
            })
            val time = TextView(ctx).apply {
                text = format(elapsedMs())
                textSize = 11f
                typeface = Typeface.MONOSPACE
                setTextColor(0xE6FFFFFF.toInt())
                includeFontPadding = false
            }
            timer = time
            bar.addView(time)
            bar.addView(btn(if (paused) IconButton.PLAY else IconButton.PAUSE, WHITE) { onTogglePause() })
            bar.addView(btn(IconButton.STOP, 0xFFFF6B6B.toInt()) { onStopRec() })
            if (replayEnabled) bar.addView(btn(IconButton.REPLAY, WHITE) { onReplay() })
        }
    }

    fun hide() {
        handler.removeCallbacks(tick)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        timer = null
        dotShape = null
    }

    private fun format(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    private companion object {
        val RED = Color.parseColor("#FF5252")
        val GRAY = Color.parseColor("#9E9E9E")
        const val WHITE = 0xE6FFFFFF.toInt()
    }

    private class IconButton(ctx: Context, private val kind: Int, tint: Int) : View(ctx) {
        companion object {
            const val PAUSE = 0
            const val PLAY = 1
            const val STOP = 2
            const val REC = 3
            const val REPLAY = 4
            const val CLOSE = 5
        }

        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            style = Paint.Style.FILL
        }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }

        override fun onDraw(c: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val s = min(width, height) * 0.27f
            stroke.strokeWidth = min(width, height) * 0.07f
            when (kind) {
                PAUSE -> {
                    c.drawRect(cx - s * 0.9f, cy - s, cx - s * 0.2f, cy + s, fill)
                    c.drawRect(cx + s * 0.2f, cy - s, cx + s * 0.9f, cy + s, fill)
                }
                PLAY -> {
                    val p = Path()
                    p.moveTo(cx - s * 0.7f, cy - s)
                    p.lineTo(cx + s, cy)
                    p.lineTo(cx - s * 0.7f, cy + s)
                    p.close()
                    c.drawPath(p, fill)
                }
                STOP -> c.drawRect(cx - s * 0.85f, cy - s * 0.85f, cx + s * 0.85f, cy + s * 0.85f, fill)
                REC -> {
                    c.drawCircle(cx, cy, s * 0.95f, fill)
                    stroke.color = 0xB3FFFFFF.toInt()
                    c.drawCircle(cx, cy, s * 1.45f, stroke)
                }
                CLOSE -> {
                    val k = s * 0.8f
                    c.drawLine(cx - k, cy - k, cx + k, cy + k, stroke)
                    c.drawLine(cx - k, cy + k, cx + k, cy - k, stroke)
                }
                REPLAY -> {
                    // Seta circular anti-horária com "15" no meio.
                    val r = s * 1.45f
                    c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -110f, -300f, false, stroke)
                    val a = Math.toRadians(-50.0)
                    val ex = cx + r * cos(a).toFloat()
                    val ey = cy + r * sin(a).toFloat()
                    val dx = sin(a).toFloat()      // tangente anti-horária
                    val dy = -cos(a).toFloat()
                    val h = s * 0.75f
                    val tip = Path()
                    tip.moveTo(ex + dx * h, ey + dy * h)
                    tip.lineTo(ex - dy * h * 0.8f, ey + dx * h * 0.8f)
                    tip.lineTo(ex + dy * h * 0.8f, ey - dx * h * 0.8f)
                    tip.close()
                    c.drawPath(tip, fill)
                    text.textSize = r * 0.95f
                    c.drawText("15", cx, cy + text.textSize * 0.35f, text)
                }
            }
        }
    }
}

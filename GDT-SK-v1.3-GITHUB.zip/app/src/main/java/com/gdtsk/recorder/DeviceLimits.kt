package com.gdtsk.recorder

import android.content.Context
import android.hardware.display.DisplayManager
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.util.DisplayMetrics
import android.util.Range
import android.view.Display
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Descobre o que o aparelho realmente suporta (codificador H.264 e tela). */
object DeviceLimits {

    private val info: MediaCodecInfo? by lazy {
        val all = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { c ->
            c.isEncoder && c.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, true) }
        }
        all.firstOrNull { Build.VERSION.SDK_INT >= 29 && it.isHardwareAccelerated } ?: all.firstOrNull()
    }

    private val caps: MediaCodecInfo.VideoCapabilities? by lazy {
        runCatching { info?.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)?.videoCapabilities }.getOrNull()
    }

    val encoderName: String? get() = info?.name

    /** Tamanho real da tela na orientação atual (largura, altura). */
    fun screenSize(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    /** Maior taxa de atualização da tela (Hz). Gravar acima disso não gera quadros novos. */
    fun maxRefreshHz(ctx: Context): Int {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
            ?: return 60
        val hz = d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
        return hz.roundToInt()
    }

    /** Converte "lado menor" (ex.: 1080) em largura x altura mantendo a proporção da tela. */
    fun sizeFor(shortSide: Int, screenW: Int, screenH: Int): Pair<Int, Int> {
        val sMin = min(screenW, screenH).toDouble()
        val sMax = max(screenW, screenH).toDouble()
        val longSide = (shortSide * sMax / sMin).roundToInt()
        var w: Int
        var h: Int
        if (screenH >= screenW) {
            w = shortSide; h = longSide
        } else {
            h = shortSide; w = longSide
        }
        val wa = caps?.widthAlignment ?: 2
        val ha = caps?.heightAlignment ?: 2
        w = max(wa, w / wa * wa)
        h = max(ha, h / ha * ha)
        return w to h
    }

    fun supportsSize(w: Int, h: Int): Boolean =
        runCatching { caps?.isSizeSupported(w, h) == true }.getOrDefault(false)

    /** Maior FPS que o codificador aceita neste tamanho (0 se não suportado). */
    fun maxFps(w: Int, h: Int): Int =
        runCatching { caps!!.getSupportedFrameRatesFor(w, h).upper.toInt() }.getOrDefault(0)

    fun bitrateRange(): Range<Int> = caps?.bitrateRange ?: Range(500_000, 100_000_000)
}

/** Ajusta o padding às barras do sistema (Android 15+ desenha de borda a borda). */
object Insets {
    fun apply(v: View) {
        if (Build.VERSION.SDK_INT < 35) return
        v.setOnApplyWindowInsetsListener { view, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            view.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }
}

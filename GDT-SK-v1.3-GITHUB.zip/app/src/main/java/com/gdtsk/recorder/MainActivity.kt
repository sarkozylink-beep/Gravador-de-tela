package com.gdtsk.recorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Switch
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {

    companion object {
        private const val REQ_PERMS = 1
        private const val REQ_PROJECTION = 2

        // Todas as opções ficam sempre visíveis. As que o aparelho não suporta
        // recebem ⚠ e são ajustadas automaticamente na hora de gravar.
        private val PRESETS = listOf(360, 480, 720, 1080, 1440, 2160)
        private val FPS_ALL = listOf(15, 24, 30, 60, 90, 120)
        private val FALLBACK_SIDES = listOf(2160, 1440, 1080, 720, 480, 360, 240)

        // Taxa de bits em Mbps. Posição 0 = Automática; depois estas; por último "Personalizada".
        private val BITRATES = listOf(1, 2, 4, 6, 8, 12, 16, 20, 30, 40, 60, 80, 100)
    }

    private lateinit var spRes: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spAudio: Spinner
    private lateinit var spBitrate: Spinner
    private lateinit var etCustom: EditText
    private lateinit var etBitrate: EditText
    private lateinit var swBubble: Switch
    private lateinit var swReplay: Switch
    private lateinit var swDark: Switch

    private var audioOptions: List<Int> = emptyList()
    private var pending: RecConfig? = null

    private val prefs by lazy { getSharedPreferences("gdtsk", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.applyTheme(this)
        setContentView(R.layout.activity_main)
        Insets.apply(findViewById(R.id.root))

        spRes = findViewById(R.id.spRes)
        spFps = findViewById(R.id.spFps)
        spAudio = findViewById(R.id.spAudio)
        spBitrate = findViewById(R.id.spBitrate)
        etCustom = findViewById(R.id.etCustom)
        etBitrate = findViewById(R.id.etBitrate)
        swBubble = findViewById(R.id.swBubble)
        swReplay = findViewById(R.id.swReplay)
        swDark = findViewById(R.id.swDark)

        val (sw, sh) = DeviceLimits.screenSize(this)
        val nativeShort = min(sw, sh)
        val refresh = DeviceLimits.maxRefreshHz(this)
        val ref = DeviceLimits.sizeFor(min(720, nativeShort), sw, sh)
        val encMax = DeviceLimits.maxFps(ref.first, ref.second)

        audioOptions = if (Build.VERSION.SDK_INT >= 29) listOf(Audio.NONE, Audio.INTERNAL, Audio.MIC)
        else listOf(Audio.NONE, Audio.MIC)

        setAdapter(spRes, PRESETS.map { p ->
            val (w, h) = DeviceLimits.sizeFor(p, sw, sh)
            val ok = DeviceLimits.supportsSize(w, h) && p <= nativeShort + 8
            if (ok) "${p}p" else "${p}p ⚠"
        } + "Personalizada")
        setAdapter(spFps, FPS_ALL.map { f ->
            val warn = f > refresh + 1 || (encMax in 1 until f)
            if (warn) "$f FPS ⚠" else "$f FPS"
        })
        val encUpper = DeviceLimits.bitrateRange().upper.toLong()
        setAdapter(spBitrate, listOf("Automática") + BITRATES.map { m ->
            if (m * 1_000_000L > encUpper) "$m Mbps ⚠" else "$m Mbps"
        } + "Personalizada")
        setAdapter(spAudio, audioOptions.map {
            when (it) {
                Audio.INTERNAL -> "Áudio interno do celular"
                Audio.MIC -> "Microfone"
                else -> "Sem áudio"
            }
        })

        spRes.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                etCustom.visibility = if (pos == PRESETS.size) View.VISIBLE else View.GONE
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        spBitrate.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                etBitrate.visibility = if (pos == BITRATES.size + 1) View.VISIBLE else View.GONE
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Restaura a última escolha.
        val savedBr = prefs.getInt("brv", -1) // -1 automática, 0 personalizada, senão Mbps
        spBitrate.setSelection(
            when {
                savedBr == 0 -> BITRATES.size + 1
                savedBr > 0 && BITRATES.contains(savedBr) -> BITRATES.indexOf(savedBr) + 1
                else -> 0
            }
        )
        val savedRes = prefs.getInt("resv", 720)
        val resIdx = PRESETS.indexOf(savedRes).let {
            if (it >= 0) it else if (savedRes == 0) PRESETS.size else PRESETS.indexOf(720)
        }
        spRes.setSelection(resIdx)
        spFps.setSelection(FPS_ALL.indexOf(prefs.getInt("fpsv", 30)).coerceAtLeast(0))
        spAudio.setSelection(prefs.getInt("audio", 0).coerceIn(0, audioOptions.size - 1))
        etCustom.setText(prefs.getString("custom", ""))
        etBitrate.setText(prefs.getString("bitrate", ""))
        swBubble.isChecked = prefs.getBoolean("bubble", true)
        swReplay.isChecked = prefs.getBoolean("replay", true)

        // Modo escuro: o valor inicial é definido ANTES do listener para não disparar recreate().
        swDark.isChecked = Ui.isDark(this)
        swDark.setOnCheckedChangeListener { _, checked ->
            savePrefs()
            Ui.setDark(this, checked)
            recreate()
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener { onStartClicked() }
        findViewById<Button>(R.id.btnList).setOnClickListener {
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
    }

    private fun setAdapter(sp: Spinner, items: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun savePrefs() {
        val resPos = spRes.selectedItemPosition
        prefs.edit()
            .putInt("resv", if (resPos in PRESETS.indices) PRESETS[resPos] else 0)
            .putInt("fpsv", FPS_ALL[spFps.selectedItemPosition.coerceIn(0, FPS_ALL.size - 1)])
            .putInt("audio", spAudio.selectedItemPosition.coerceAtLeast(0))
            .putInt(
                "brv",
                spBitrate.selectedItemPosition.let { p ->
                    when {
                        p <= 0 -> -1
                        p <= BITRATES.size -> BITRATES[p - 1]
                        else -> 0
                    }
                }
            )
            .putString("custom", etCustom.text.toString())
            .putString("bitrate", etBitrate.text.toString())
            .putBoolean("bubble", swBubble.isChecked)
            .putBoolean("replay", swReplay.isChecked)
            .apply()
    }

    // ------------------------------------------------------------------ fluxo de início

    private fun onStartClicked() {
        if (RecorderService.active) {
            toast("A bolha já está ativa. Toque em ● na bolha para gravar.")
            return
        }
        pending = buildConfig() ?: return
        ensurePermissions()
    }

    private fun buildConfig(): RecConfig? {
        savePrefs()
        val (sw, sh) = DeviceLimits.screenSize(this)

        val resPos = spRes.selectedItemPosition
        val shortSide = if (resPos in PRESETS.indices) {
            PRESETS[resPos]
        } else {
            val v = etCustom.text.toString().trim().toIntOrNull()
            if (v == null || v < 144) {
                toast("Informe o lado menor da resolução em pixels (mínimo 144).")
                return null
            }
            v
        }

        // Se o codificador não aceitar o tamanho escolhido, desce para o maior que ele aceita.
        var adapted = false
        var size = DeviceLimits.sizeFor(shortSide, sw, sh)
        if (!DeviceLimits.supportsSize(size.first, size.second)) {
            val alt = FALLBACK_SIDES.filter { it < shortSide }
                .map { DeviceLimits.sizeFor(it, sw, sh) }
                .firstOrNull { DeviceLimits.supportsSize(it.first, it.second) }
            if (alt == null) {
                toast("Este aparelho não consegue gravar nessa resolução.")
                return null
            }
            size = alt
            adapted = true
        }
        val (w, h) = size

        // Mesma regra para o FPS.
        var fps = FPS_ALL[spFps.selectedItemPosition.coerceIn(0, FPS_ALL.size - 1)]
        val maxFps = DeviceLimits.maxFps(w, h)
        if (maxFps in 1 until fps) {
            fps = FPS_ALL.lastOrNull { it <= maxFps } ?: maxFps
            adapted = true
        }
        if (adapted) toast("Aparelho sem suporte para o escolhido. Gravando em ${min(w, h)}p, $fps FPS.")

        val range = DeviceLimits.bitrateRange()
        val brPos = spBitrate.selectedItemPosition.coerceAtLeast(0)
        val chosenMbps: Double? = when {
            brPos == 0 -> null
            brPos <= BITRATES.size -> BITRATES[brPos - 1].toDouble()
            else -> {
                val t = etBitrate.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (t == null || t <= 0) {
                    toast("Informe a taxa de bits em Mbps (ex.: 7,5).")
                    return null
                }
                t
            }
        }
        val rawBitrate = if (chosenMbps != null) chosenMbps * 1_000_000.0
        else w.toDouble() * h * fps * 0.07 // automática: ~0,07 bit por pixel por quadro
        val bitrate = rawBitrate.toLong().coerceIn(range.lower.toLong(), range.upper.toLong()).toInt()
        if (chosenMbps != null && bitrate.toLong() != rawBitrate.toLong()) {
            toast("Taxa de bits ajustada para %.1f Mbps (limite do aparelho).".format(bitrate / 1_000_000.0))
        }

        val audio = audioOptions[spAudio.selectedItemPosition.coerceIn(0, audioOptions.size - 1)]
        val bubble = swBubble.isChecked

        return RecConfig(w, h, fps, bitrate, audio, bubble, resources.displayMetrics.densityDpi, swReplay.isChecked)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions() {
        val cfg = pending ?: return
        val need = ArrayList<String>()
        if (cfg.audio != Audio.NONE && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_PERMS) else askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        var cfg = pending ?: return
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            toast("A permissão de armazenamento é necessária para salvar os vídeos.")
            pending = null
            return
        }
        if (cfg.audio != Audio.NONE && !has(Manifest.permission.RECORD_AUDIO)) {
            cfg = cfg.copy(audio = Audio.NONE)
            pending = cfg
            toast("Sem permissão de áudio: gravando sem som.")
        }
        // Notificações negadas não impedem de gravar (a bolha continua funcionando).
        askProjection()
    }

    private fun askProjection() {
        val cfg = pending ?: return
        if (cfg.bubble && !Settings.canDrawOverlays(this)) {
            toast("Permita \"Sobrepor a outros apps\" e toque em Ativar de novo.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            pending = null
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJECTION) return
        val cfg = pending
        pending = null
        if (resultCode != RESULT_OK || data == null || cfg == null) {
            toast("Captura de tela não autorizada.")
            return
        }
        val i = Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START)
        cfg.putTo(i)
        i.putExtra(RecorderService.EXTRA_CODE, resultCode)
        i.putExtra(RecorderService.EXTRA_DATA, data)
        startForegroundService(i)
        toast(
            if (cfg.bubble) "Bolha ativa. Toque em ● para começar a gravar."
            else "Pronto. Use \"Gravar\" na notificação para começar."
        )
        moveTaskToBack(true) // sai da frente para não aparecer no vídeo
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}

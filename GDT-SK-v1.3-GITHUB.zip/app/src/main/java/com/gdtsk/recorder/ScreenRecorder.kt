package com.gdtsk.recorder

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Surface
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Pipeline: VirtualDisplay -> MediaCodec (H.264)  \
 *           AudioRecord -> MediaCodec (AAC)        /-> [buffer dos últimos 15 s] e/ou [MP4 da gravação]
 *
 * O captador fica ligado desde start() ("espera"). A gravação (startRecording/stopRecording) só
 * liga e desliga o arquivo MP4, então dá para começar quando quiser sem pedir permissão de novo.
 * Com cfg.replay ligado, os últimos REPLAY_SECONDS segundos (já codificados) ficam na memória
 * e saveReplay() os grava num MP4 à parte.
 */
class ScreenRecorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val cfg: RecConfig,
    private val onError: (String) -> Unit,
    private val onWarning: (String) -> Unit,
) {
    companion object {
        const val REPLAY_SECONDS = 15
        private const val SAMPLE_RATE = 44100
        private const val TIMEOUT_US = 10_000L
    }

    private class Sample(val video: Boolean, val data: ByteArray, val flags: Int, val tsUs: Long) {
        val key get() = (flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
    }

    /** Gravação já desligada do fluxo, esperando ser finalizada (pode demorar, fora da thread principal). */
    class Pending internal constructor(
        internal val muxer: MediaMuxer?,
        internal val out: Storage.Output?,
        internal val ok: Boolean,
    )

    private var videoCodec: MediaCodec? = null
    private var audioCodec: MediaCodec? = null
    private var audioRecord: AudioRecord? = null
    private var audioChannels = 2
    private var inputSurface: Surface? = null
    private var display: VirtualDisplay? = null
    private var drainThread: Thread? = null
    private var audioThread: Thread? = null

    @Volatile private var audioRunning = false
    @Volatile private var videoFormat: MediaFormat? = null
    @Volatile private var audioFormat: MediaFormat? = null
    @Volatile private var recording = false
    @Volatile private var paused = false
    @Volatile private var latestTs = 0L

    private var startUs = 0L
    private var videoBase = Long.MIN_VALUE
    private var stopped = false
    private var resultUri: Uri? = null

    private val lock = Any()

    // Buffer dos últimos segundos (protegido por lock)
    private val vRing = ArrayDeque<Sample>()
    private val aRing = ArrayDeque<Sample>()
    private val keyTs = ArrayDeque<Long>()

    // Saída da gravação (protegido por lock)
    private var sinkOut: Storage.Output? = null
    private var sinkMuxer: MediaMuxer? = null
    private var sinkStarted = false
    private var sinkWrote = false
    private var waitKey = false
    private var sinkBase = 0L
    private var pausedTotal = 0L
    private var pausePointTs = 0L
    private var audioFloor = 0L
    private var lastV = -1L
    private var lastA = -1L
    private var vTrack = -1
    private var aTrack = -1
    private val writeInfo = MediaCodec.BufferInfo()

    // ------------------------------------------------------------------ início (espera)

    fun start() {
        try {
            startUs = System.nanoTime() / 1000

            val name = DeviceLimits.encoderName
            val vc = if (name != null) MediaCodec.createByCodecName(name)
            else MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, cfg.width, cfg.height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, cfg.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fps)
                // Com o buffer ligado, quadro-chave a cada 1 s deixa o corte dos "últimos 15 s" bem preciso.
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, if (cfg.replay) 1 else 2)
                setInteger(MediaFormat.KEY_OPERATING_RATE, cfg.fps)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
                // Se a tela ficar parada, repete o último quadro para o vídeo não "travar".
                setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / min(cfg.fps, 30))
            }
            vc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = vc.createInputSurface()
            vc.start()
            videoCodec = vc

            setupAudio()

            display = projection.createVirtualDisplay(
                "GDTSK", cfg.width, cfg.height, cfg.dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface, null, null
            ) ?: throw IllegalStateException("Não foi possível iniciar a captura da tela.")

            drainThread = Thread({ drainLoop() }, "gdtsk-drain").also { it.start() }
            if (audioCodec != null) {
                audioRunning = true
                audioThread = Thread({ audioLoop() }, "gdtsk-audio").also { it.start() }
            }
        } catch (e: Exception) {
            releaseAll()
            throw e
        }
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio() {
        if (cfg.audio == Audio.NONE) return
        var rec: AudioRecord? = null
        var codec: MediaCodec? = null
        try {
            val mic = cfg.audio == Audio.MIC
            val channels = if (mic) 1 else 2
            val mask = if (mic) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
            val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, mask, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) throw IllegalStateException("buffer de áudio inválido")
            val size = max(minBuf * 2, 16384)

            rec = if (mic) {
                AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, mask, AudioFormat.ENCODING_PCM_16BIT, size)
            } else {
                if (Build.VERSION.SDK_INT < 29) throw IllegalStateException("áudio interno exige Android 10+")
                val pc = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                AudioRecord.Builder()
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(mask)
                            .build()
                    )
                    .setBufferSizeInBytes(size)
                    .setAudioPlaybackCaptureConfig(pc)
                    .build()
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("AudioRecord não inicializou")
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("AudioRecord não gravou")

            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, if (channels == 2) 128_000 else 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            audioRecord = rec
            audioChannels = channels
            audioCodec = codec
        } catch (e: Exception) {
            runCatching { rec?.stop() }
            runCatching { rec?.release() }
            runCatching { codec?.release() }
            audioRecord = null
            audioCodec = null
            onWarning("Áudio indisponível neste modo/aparelho. Gravando sem áudio.")
        }
    }

    // ------------------------------------------------------------------ gravação (liga/desliga o arquivo)

    /** Abre o MP4 e passa a gravar a partir do próximo quadro-chave. Retorna false se não deu para criar o arquivo. */
    fun startRecording(): Boolean {
        synchronized(lock) {
            if (stopped || recording) return false
            val out = try {
                Storage.open(ctx, "GDTSK_")
            } catch (e: Exception) {
                onWarning("Não foi possível criar o arquivo: ${e.message ?: e.javaClass.simpleName}")
                return false
            }
            sinkOut = out
            sinkMuxer = out.muxer
            sinkStarted = false
            sinkWrote = false
            waitKey = true
            sinkBase = 0L
            pausedTotal = 0L
            pausePointTs = 0L
            audioFloor = 0L
            lastV = -1L
            lastA = -1L
            vTrack = -1
            aTrack = -1
            paused = false
            recording = true
        }
        requestSync()
        return true
    }

    fun pauseRecording() {
        synchronized(lock) {
            if (!recording || paused) return
            pausePointTs = latestTs
            paused = true
        }
    }

    fun resumeRecording() {
        synchronized(lock) {
            if (!recording || !paused) return
            paused = false
            waitKey = true // volta a gravar no próximo quadro-chave (os quadros da pausa foram descartados)
        }
        requestSync()
    }

    /** Desliga o arquivo do fluxo na hora (rápido). Finalize com finishRecording() fora da thread principal. */
    fun detachRecording(): Pending? {
        synchronized(lock) {
            if (!recording) return null
            recording = false
            paused = false
            val p = Pending(sinkMuxer, sinkOut, sinkStarted && sinkWrote)
            sinkMuxer = null
            sinkOut = null
            sinkStarted = false
            return p
        }
    }

    /** Finaliza o MP4 e o publica na galeria. Bloqueante. */
    fun finishRecording(p: Pending): Uri? {
        var ok = false
        if (p.muxer != null && p.ok) {
            ok = try {
                p.muxer.stop()
                true
            } catch (e: Exception) {
                false
            }
        }
        runCatching { p.muxer?.release() }
        return p.out?.close(ok)
    }

    private fun requestSync() {
        videoCodec?.let {
            runCatching { it.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }) }
        }
    }

    // ------------------------------------------------------------------ últimos 15 s

    /** Grava o buffer num MP4 à parte. Bloqueante. Retorna null se ainda não há vídeo suficiente. */
    fun saveReplay(): Uri? {
        if (!cfg.replay) return null
        val v: List<Sample>
        val a: List<Sample>
        synchronized(lock) {
            v = ArrayList(vRing)
            a = ArrayList(aRing)
        }
        val first = v.indexOfFirst { it.key }
        if (first < 0) return null
        val vs = v.subList(first, v.size)
        if (vs.size < 2) return null
        val vf = videoFormat ?: return null
        val af = audioFormat
        val base = vs[0].tsUs
        val aud = if (audioCodec != null && af != null) a.filter { it.tsUs >= base } else emptyList()

        val out = Storage.open(ctx, "GDTSK_Replay_")
        val m = out.muxer
        var ok = false
        try {
            val vt = m.addTrack(vf)
            val at = if (aud.isNotEmpty() && af != null) m.addTrack(af) else -1
            m.start()
            val info = MediaCodec.BufferInfo()
            var i = 0
            var j = 0
            var lastVo = -1L
            var lastAo = -1L
            while (i < vs.size || j < aud.size) {
                val useVideo = j >= aud.size || (i < vs.size && vs[i].tsUs <= aud[j].tsUs)
                val s = if (useVideo) vs[i++] else aud[j++]
                if (!useVideo && at < 0) continue
                var t = s.tsUs - base
                if (useVideo) {
                    if (t <= lastVo) t = lastVo + 1
                    lastVo = t
                } else {
                    if (t <= lastAo) t = lastAo + 1
                    lastAo = t
                }
                info.set(0, s.data.size, t, s.flags)
                m.writeSampleData(if (useVideo) vt else at, ByteBuffer.wrap(s.data), info)
            }
            m.stop()
            ok = true
        } catch (e: Exception) {
            ok = false
        } finally {
            runCatching { m.release() }
        }
        return out.close(ok)
    }

    // ------------------------------------------------------------------ parada total

    /** Encerra tudo. Se havia gravação em andamento, finaliza e retorna o arquivo. Bloqueante. */
    fun stop(): Uri? {
        synchronized(this) {
            if (stopped) return resultUri
            stopped = true
        }
        val pending = detachRecording()
        runCatching { display?.release() }
        videoCodec?.let { runCatching { it.signalEndOfInputStream() } }
        audioRunning = false
        runCatching { audioThread?.join(3000) }
        runCatching { drainThread?.join(6000) }
        releaseAll()
        synchronized(lock) {
            vRing.clear()
            aRing.clear()
            keyTs.clear()
        }
        resultUri = pending?.let { finishRecording(it) }
        return resultUri
    }

    private fun releaseAll() {
        runCatching { display?.release() }
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        runCatching { audioCodec?.stop() }
        runCatching { audioCodec?.release() }
        runCatching { videoCodec?.stop() }
        runCatching { videoCodec?.release() }
        runCatching { inputSurface?.release() }
    }

    // ------------------------------------------------------------------ drenagem dos codificadores

    private fun drainLoop() {
        try {
            val info = MediaCodec.BufferInfo()
            var videoDone = false
            var audioDone = audioCodec == null
            while (!(videoDone && audioDone)) {
                if (!videoDone) videoDone = drain(videoCodec!!, true, info)
                if (!audioDone) audioDone = drain(audioCodec!!, false, info)
            }
        } catch (e: Exception) {
            if (!stopped) onError("Erro na captura: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Esvazia o codificador. Retorna true quando chegou ao fim do fluxo. */
    private fun drain(codec: MediaCodec, video: Boolean, info: MediaCodec.BufferInfo): Boolean {
        while (true) {
            val idx = codec.dequeueOutputBuffer(info, TIMEOUT_US)
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (video) videoFormat = codec.outputFormat else audioFormat = codec.outputFormat
                }
                idx >= 0 -> {
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    val buf = codec.getOutputBuffer(idx)
                    if (info.size > 0 && buf != null) handleSample(buf, info, video)
                    codec.releaseOutputBuffer(idx, false)
                    if (eos) return true
                }
            }
        }
    }

    private fun needMedia() = cfg.replay || (recording && !paused)

    private fun handleSample(buf: ByteBuffer, info: MediaCodec.BufferInfo, video: Boolean) {
        if (!needMedia()) return // em espera sem buffer: descarta
        var t = info.presentationTimeUs
        if (video) {
            if (videoBase == Long.MIN_VALUE) {
                val now = System.nanoTime() / 1000
                // Mesma base de tempo do relógio do sistema: alinha com o áudio (que parte de startUs).
                videoBase = if (abs(t - now) < 5_000_000L) startUs else t - (now - startUs)
            }
            t -= videoBase
        }
        if (t < 0) t = 0
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        val data = ByteArray(info.size)
        buf.get(data)
        val s = Sample(video, data, info.flags, t)
        if (video && t > latestTs) latestTs = t
        synchronized(lock) {
            if (cfg.replay) pushRing(s)
            if (recording && !paused) sinkWrite(s)
        }
    }

    // ------------------------------------------------------------------ buffer circular

    private fun pushRing(s: Sample) {
        if (!s.video) {
            aRing.addLast(s)
            return
        }
        if (!s.key && vRing.isEmpty()) return // o buffer sempre começa num quadro-chave
        vRing.addLast(s)
        if (s.key) keyTs.addLast(s.tsUs)
        // Mantém desde o último quadro-chave que ainda cobre os últimos REPLAY_SECONDS.
        val limit = s.tsUs - REPLAY_SECONDS * 1_000_000L
        while (keyTs.size >= 2 && keyTs[1] <= limit) {
            val newHead = keyTs[1]
            while (vRing.isNotEmpty() && !(vRing.first().key && vRing.first().tsUs == newHead)) vRing.removeFirst()
            keyTs.removeFirst()
        }
        val cut = if (keyTs.isNotEmpty()) keyTs.first() else 0L
        while (aRing.isNotEmpty() && aRing.first().tsUs < cut) aRing.removeFirst()
    }

    // ------------------------------------------------------------------ arquivo da gravação

    private fun sinkWrite(s: Sample) {
        val m = sinkMuxer ?: return
        try {
            if (!sinkStarted) {
                if (!s.video || !s.key) return
                val vf = videoFormat ?: return
                val af = audioFormat
                if (audioCodec != null && af == null) return // espera o formato do áudio
                vTrack = m.addTrack(vf)
                aTrack = if (audioCodec != null && af != null) m.addTrack(af) else -1
                m.start()
                sinkStarted = true
                waitKey = false
                sinkBase = s.tsUs
                audioFloor = s.tsUs
            } else if (waitKey) {
                if (!s.video || !s.key) return
                pausedTotal += max(0L, s.tsUs - pausePointTs)
                audioFloor = s.tsUs
                waitKey = false
            }
            if (!s.video && s.tsUs < audioFloor) return
            val track = if (s.video) vTrack else aTrack
            if (track < 0) return
            var t = s.tsUs - sinkBase - pausedTotal
            if (t < 0) t = 0
            if (s.video) {
                if (t <= lastV) t = lastV + 1
                lastV = t
            } else {
                if (t <= lastA) t = lastA + 1
                lastA = t
            }
            writeInfo.set(0, s.data.size, t, s.flags)
            m.writeSampleData(track, ByteBuffer.wrap(s.data), writeInfo)
            sinkWrote = true
        } catch (e: Exception) {
            onError("Erro ao gravar o arquivo: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ áudio

    private fun audioLoop() {
        val rec = audioRecord ?: return
        val codec = audioCodec ?: return
        val bytesPerFrame = 2 * audioChannels
        val chunk = ByteArray(4096)
        var frames = 0L
        var baseUs = 0L
        var resync = true
        try {
            // Um pedaço de silêncio no começo faz o AAC revelar o formato cedo (o MP4 precisa dele para iniciar).
            val pi = codec.dequeueInputBuffer(TIMEOUT_US)
            if (pi >= 0) {
                val ib = codec.getInputBuffer(pi)
                if (ib != null) {
                    ib.clear()
                    val len = 1024 * bytesPerFrame
                    ib.put(ByteArray(len))
                    codec.queueInputBuffer(pi, 0, len, 0, 0)
                }
            }
            while (audioRunning) {
                val n = rec.read(chunk, 0, chunk.size)
                if (n < 0) {
                    onWarning("Captura de áudio interrompida.")
                    break
                }
                if (n == 0) continue
                if (!needMedia()) { // em espera sem buffer, ou gravação pausada: lê e descarta
                    resync = true
                    continue
                }
                if (resync) {
                    val chunkUs = (n / bytesPerFrame) * 1_000_000L / SAMPLE_RATE
                    baseUs = max(50_000L, System.nanoTime() / 1000 - startUs - chunkUs)
                    frames = 0L
                    resync = false
                }
                var off = 0
                while (off < n && audioRunning) {
                    val i = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (i < 0) continue
                    val ib = codec.getInputBuffer(i) ?: continue
                    ib.clear()
                    var len = min(n - off, ib.remaining())
                    len = len / bytesPerFrame * bytesPerFrame
                    if (len <= 0) {
                        codec.queueInputBuffer(i, 0, 0, 0, 0)
                        break
                    }
                    ib.put(chunk, off, len)
                    codec.queueInputBuffer(i, 0, len, baseUs + frames * 1_000_000L / SAMPLE_RATE, 0)
                    frames += len / bytesPerFrame
                    off += len
                }
            }
        } catch (e: Exception) {
            onWarning("Captura de áudio interrompida.")
        }
        sendEos(codec, baseUs + frames * 1_000_000L / SAMPLE_RATE)
    }

    private fun sendEos(codec: MediaCodec, ptsUs: Long) {
        repeat(300) {
            try {
                val i = codec.dequeueInputBuffer(TIMEOUT_US)
                if (i >= 0) {
                    codec.queueInputBuffer(i, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    return
                }
            } catch (e: Exception) {
                return
            }
        }
    }
}

package com.gdtsk.recorder

import android.content.Intent

object Audio {
    const val NONE = 0
    const val INTERNAL = 1
    const val MIC = 2
}

/** Configuração escolhida pelo usuário antes de gravar. */
data class RecConfig(
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Int,
    val audio: Int,
    val bubble: Boolean,
    val dpi: Int,
    val replay: Boolean = false,
) {
    fun putTo(i: Intent): Intent = i
        .putExtra("w", width)
        .putExtra("h", height)
        .putExtra("fps", fps)
        .putExtra("br", bitrate)
        .putExtra("audio", audio)
        .putExtra("bubble", bubble)
        .putExtra("dpi", dpi)
        .putExtra("rp", replay)

    companion object {
        fun from(i: Intent) = RecConfig(
            width = i.getIntExtra("w", 720),
            height = i.getIntExtra("h", 1280),
            fps = i.getIntExtra("fps", 30),
            bitrate = i.getIntExtra("br", 6_000_000),
            audio = i.getIntExtra("audio", Audio.NONE),
            bubble = i.getBooleanExtra("bubble", false),
            dpi = i.getIntExtra("dpi", 320),
            replay = i.getBooleanExtra("rp", false),
        )
    }
}
